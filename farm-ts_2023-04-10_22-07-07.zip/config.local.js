window.LOCAL_CONFIG = {
  // API_HOME:'/api'
  // API_HOME:'http://10.20.35.85:8088'
  API_HOME:'https://console-mock.apipost.cn/app/mock/project/262231ae-00f4-4861-bf26-4148b4120b30'
}
